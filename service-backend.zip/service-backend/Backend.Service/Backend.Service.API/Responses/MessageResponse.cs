﻿using System;

namespace Backend.Service.Responses
{
    public class MessageResponse
    {
        public Guid Id { get; set; }
        public string Result { get; set; }
        
        public Meta Meta { get; set; }
    }

    public struct Meta
    {
        public DateTime DateTimeReceived { get; set; }
        public DateTime DateTimeCompleted { get; set; }
        public double ProcessingTimeMilliseconds { get; set; }
        public string MachineName { get; set; }
    }
}