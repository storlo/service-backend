﻿using System;
using System.Collections.Generic;
using Backend.Service.Responses;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Net.Mime;
using System.Threading.Tasks;
using System.Web;
using Backend.Service.Application.Commands;
using Backend.Service.Application.Queries;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Backend.Service.Application.Options;

namespace Backend.Service.API.Controllers
{
    [ApiController]
    [Route("messages")]
    public class MessageController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IMessageQueries _messageQueries;


        public MessageController(
            IMediator mediator,
            IMessageQueries messageQueries)
        {
            _mediator = mediator;
            _messageQueries = messageQueries;
            
        }

        
        [HttpPost()]
        public async Task<ActionResult> SendMessage(MessageCommand command)
        {
            DateTime dateTimeReceived = DateTime.Now;
            var result = await _mediator.Send(command);

            return Ok( new MessageResponse {
                Id = command.Id,
                Result = result,
                Meta = new Meta { 
                    DateTimeReceived = dateTimeReceived,
                    DateTimeCompleted = DateTime.Now,
                    ProcessingTimeMilliseconds = (DateTime.Now - dateTimeReceived).TotalMilliseconds,
                    MachineName = Environment.MachineName
                }
            });   
        }
    }
}