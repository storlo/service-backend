﻿using Microsoft.AspNetCore.Http;

namespace Backend.Service.Requests
{
    public class MessageRequest
    {
        public int Id { get; set; }
        public string Data { get; set; }
    }
}
