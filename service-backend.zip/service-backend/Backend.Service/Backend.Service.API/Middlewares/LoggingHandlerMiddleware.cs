using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace Backend.Service.API.Middlewares.Logging
{
    public class LoggingHandlerMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<LoggingHandlerMiddleware> _logger;

        public LoggingHandlerMiddleware(RequestDelegate next, ILogger<LoggingHandlerMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
        }
    }
}