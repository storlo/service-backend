﻿using System;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace Backend.Service.API.Middlewares.Exceptions
{
    public class ExceptionHandlerMiddleware
    {
        private const string ContentType = "application/json; charset=utf-8";

        private readonly RequestDelegate _next;

        public ExceptionHandlerMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (CustomExceptionBase ex)
            {
                await HandleCustomExceptionAsync(context, ex);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private static async Task HandleCustomExceptionAsync(HttpContext context, CustomExceptionBase customException)
        {
            var bodyJson = JsonConvert.SerializeObject(customException.Response);

            context.Response.StatusCode = customException.StatusCode;
            context.Response.ContentType = ContentType;
            await context.Response.WriteAsync(bodyJson, Encoding.UTF8);
        }

        private static async Task HandleExceptionAsync(HttpContext context, Exception ex)
        {
            var body = new[] { new ExceptionResponse { Message = ex.Message } };
            var bodyJson = JsonConvert.SerializeObject(body);

            context.Response.StatusCode = StatusCodes.Status500InternalServerError;
            context.Response.ContentType = ContentType;
            await context.Response.WriteAsync(bodyJson, Encoding.UTF8);
        }
    }
}