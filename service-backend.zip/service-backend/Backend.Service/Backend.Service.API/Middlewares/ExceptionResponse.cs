﻿namespace Backend.Service.API.Middlewares.Exceptions
{
    public class ExceptionResponse
    {
        public string Message { get; set; }

        public string Field { get; set; }
    }
}