﻿using System;
using System.Collections.Generic;

namespace Backend.Service.API.Middlewares.Exceptions
{
    public abstract class CustomExceptionBase : Exception
    {
        public abstract int StatusCode { get; }

        public abstract ICollection<ExceptionResponse> Response { get; }
    }
}