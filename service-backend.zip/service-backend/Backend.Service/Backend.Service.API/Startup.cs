using System.Reflection;

using Backend.Service.Setups;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MediatR;
using System;
using Backend.Service.API.Middlewares.Exceptions;
using Backend.Service.API.Middlewares.Logging;
using System.Collections.Generic;
using Backend.Service.Application.Options;
using Backend.Service.Application.Services;

namespace Backend.Service
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddOpenApiDocument(settings =>
            {
                settings.DocumentName = "API";
                settings.PostProcess = document =>
                {
                    document.Info.Version = "1.1.1.0";
                    document.Info.Title = "Backend service API";
                };
            });

            services.Configure<Services>(Configuration.GetSection("Services"));

            services.AddMediatR(Assembly.GetExecutingAssembly());

            // Multithread processing
            services.AddSingleton<Manager>();

            services.AddControllers();

            services.ConfigureHealthChecks();
        }

        public void Configure(IApplicationBuilder app)
        {
            app.UseOpenApi();
            app.UseSwaggerUi3();

            app.UseMiddleware<ExceptionHandlerMiddleware>();
            app.UseMiddleware<LoggingHandlerMiddleware>();

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHealthChecks();
            });
        }
    }
}