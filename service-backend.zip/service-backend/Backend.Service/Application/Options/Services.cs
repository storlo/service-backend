using Backend.Service.Application.Commands;
using System.Collections.Generic;

namespace Backend.Service.Application.Options
{
    public class Services
    {
        public List<Processor> Processors { get; set; }
    }

    public class Processor
    {
        public MessageType MessageType { get; set; }
        public int MaxThreads { get; set; }
    }
}