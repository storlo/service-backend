﻿using MediatR;
using System;

namespace Backend.Service.Application.Commands
{
    public class MessageCommand : IMessage<string>
    {
        public Guid Id { get; set; }
        public MessageType MessageType { get; set; }
        public string Data { get; set; }
    }

    public enum MessageType
    {
        None,
        WordsReverse,
        WordsCount,
        IntegerSum
    }
}
