﻿using System;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Backend.Service.Application.Services;
using MediatR;
using Microsoft.Extensions.Hosting;


namespace Backend.Service.Application.Commands
{
    public class MessageCommandHandler : IRequestHandler<MessageCommand, string>
    {
        private readonly Manager _manager;

        public MessageCommandHandler(Manager processor)
        {
            _manager = processor;
        }

        public async Task<string> Handle(MessageCommand command, CancellationToken cancellationToken)
        {
            var result = await _manager.Process(command.MessageType, command.Data);

            return result;
        }
    }
}
