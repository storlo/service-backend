﻿using Backend.Service.Application.Commands;
using FluentValidation;

namespace Backend.Service.Application.Validators
{
    public class AddProcessMessageCommandValidator : AbstractValidator<IMessage<string>>
    {
        public AddProcessMessageCommandValidator()
        {
            RuleFor(s => s.Id)
                .NotEmpty();
        }
    }
}
