﻿using System;
using System.Linq;
using System.Threading.Tasks;


namespace Backend.Service.Application.Queries
{
    public interface IMessageQueries : IQueries<IMessageQueries>
    {
    }
}
