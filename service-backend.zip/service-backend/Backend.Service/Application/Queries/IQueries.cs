﻿namespace Backend.Service.Application.Queries
{
    public interface IQueries<T>
    {
    }
}
