﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.IO.Compression;
using Backend.Service.Application.Services;

namespace Backend.Service.Application.Queries
{
    public class MessageQueries : IMessageQueries
    {
        private readonly Manager _manager;

        public MessageQueries(Manager manager)
        {
            _manager = manager ?? throw new ArgumentNullException(nameof(manager));
        }
    }
}
