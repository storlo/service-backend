﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Backend.Service.Application.Commands;
using Backend.Service.Application.Options;
using Microsoft.Extensions.Options;

namespace Backend.Service.Application.Services.Processors
{
    public abstract class ProcessorBase : IProcessor
    {
        private SemaphoreSlim _concurrencySemaphore;

        public MessageType MessageType { get; }

        public ProcessorBase(MessageType messageType, int maxThreads)
        {
            MessageType = messageType;
            _concurrencySemaphore = new SemaphoreSlim(maxThreads, maxThreads);
        }

        public void Dispose()
        {
            _concurrencySemaphore.Dispose();
        }

        public async Task<string> Process(string data)
        {
            // parallel queue
            _concurrencySemaphore.Wait();
            var t = Task.Factory.StartNew(() =>
            {
                try
                {
                    return ProcessStrategy(data);
                }
                finally
                {
                    _concurrencySemaphore.Release();
                }
            });

            return await t;
        }

        protected abstract string ProcessStrategy(string data);

    }
}
