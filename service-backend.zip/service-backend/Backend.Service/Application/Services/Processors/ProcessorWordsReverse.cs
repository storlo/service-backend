﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Backend.Service.Application.Commands;
using Backend.Service.Application.Options;
using Microsoft.Extensions.Options;

namespace Backend.Service.Application.Services.Processors
{
    public class ProcessorWordsReverse : ProcessorBase
    {
        public ProcessorWordsReverse(MessageType messageType, int maxThreads) : base(messageType, maxThreads) { }

        /// <summary>
        /// Words Reverse
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        protected override string ProcessStrategy(string data)
        {
            Thread.Sleep(10000);

            string[] dataSplitted = data.Split(" ");
            StringBuilder result = new StringBuilder();
            for (int i = dataSplitted.Count() - 1; i >= 0; i--)
            {
                result.Append(dataSplitted[i]).Append(" ");
            }

            return result.ToString().TrimEnd();
        }

     
    }
}
