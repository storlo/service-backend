﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Backend.Service.Application.Commands;
using Backend.Service.Application.Options;
using Microsoft.Extensions.Options;

namespace Backend.Service.Application.Services.Processors
{
    public class ProcessorIntegerSum : ProcessorBase
    {

        public ProcessorIntegerSum(MessageType messageType, int maxThreads) : base(messageType, maxThreads) { }




        protected override string ProcessStrategy(string data)
        {
            string[] numbers = data.Split(" ");
            
            return (int.Parse(numbers[0]) + int.Parse(numbers[1])).ToString();
        }


    }
}
