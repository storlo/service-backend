﻿using Backend.Service.Application.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backend.Service.Application.Services.Processors
{
    public interface IProcessor : IDisposable
    {
        MessageType MessageType { get; }
        Task<string> Process(string data);
    }
}
