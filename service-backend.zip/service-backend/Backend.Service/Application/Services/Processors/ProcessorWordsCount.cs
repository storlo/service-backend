﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Backend.Service.Application.Commands;
using Backend.Service.Application.Options;
using Microsoft.Extensions.Options;

namespace Backend.Service.Application.Services.Processors
{
    public class ProcessorWordsCount : ProcessorBase
    {
        public ProcessorWordsCount(MessageType messageType, int maxThreads) : base(messageType, maxThreads) { }

        /// <summary>
        /// Words Count
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        protected override string ProcessStrategy(string data)
        {
            throw new Exception("---test---");
            return (data.TrimEnd().Split(" ").Length).ToString();
        }

    }

}
