﻿using Backend.Service.Application.Commands;
using Backend.Service.Application.Services.Processors;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Backend.Service.Application.Services
{
    public class Manager : IDisposable
    {
        private List<IProcessor> _processors = new List<IProcessor>();
        private readonly Options.Services _optionsServices;

        public Manager(IOptions<Options.Services> optionsServices)
        {
            _optionsServices = optionsServices.Value;

            foreach (var optionsProcessor in _optionsServices.Processors)
            {
                IProcessor processor;
                switch (optionsProcessor.MessageType)
                {
                    case MessageType.WordsReverse:
                        processor = new ProcessorWordsReverse(optionsProcessor.MessageType, optionsProcessor.MaxThreads);
                        break;
                    case MessageType.WordsCount:
                        processor = new ProcessorWordsCount(optionsProcessor.MessageType, optionsProcessor.MaxThreads);
                        break;
                    case MessageType.IntegerSum:
                        processor = new ProcessorIntegerSum(optionsProcessor.MessageType, optionsProcessor.MaxThreads);
                        break;
                    default: throw new NotImplementedException($"No processor for {optionsProcessor.MessageType}");
                }
                _processors.Add(processor);
            }
        }

        public async Task<string> Process(MessageType messageType, string data)
        {
            return await _processors.First( p => p.MessageType == messageType).Process(data);
        }

        public void Dispose()
        {
            foreach (var processor in _processors)
            {
                processor.Dispose();
            }

        }
    }
}
